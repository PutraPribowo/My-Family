package com.developerputra.myfamily;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.developerputra.myfamily.model.CardViewKeluargaAdapter;
import com.developerputra.myfamily.model.Keluarga;
import com.developerputra.myfamily.model.KeluargaData;

import java.util.ArrayList;

public class Utama extends AppCompatActivity {
    private RecyclerView rvCategory;
    private ArrayList<Keluarga> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_utama);

        rvCategory = findViewById(R.id.rv_category);
        rvCategory.setHasFixedSize(true);

        list = new ArrayList<>();
        list.addAll(KeluargaData.getListData());
        showRecyclerCardView();

    }

    private void showRecyclerCardView() {
        rvCategory.setLayoutManager(new LinearLayoutManager(this));
        CardViewKeluargaAdapter cardViewKeluargaAdapter = new CardViewKeluargaAdapter(this);
        cardViewKeluargaAdapter.setListKeluarga(list);
        rvCategory.setAdapter(cardViewKeluargaAdapter);
    }

}
